package allses;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class allsession
 */
@WebServlet("/allsession")
public class allsession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public allsession() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session = request.getSession(true);
		Date ct = new Date(session.getCreationTime());
		Date lt = new Date(session.getLastAccessedTime());
		String title ="Welcome back to my web";
		Integer vc=new Integer(0);
		String vck =new String("vc");
		String uik= new String("ui");
		String ui =new String("ABCD");
		
		if(session.isNew()){
			title="Welcome to my Web";
			session.setAttribute(uik, ui);
		}else{
			vc=(Integer)session.getAttribute(vck);
			vc = vc + 1;
			ui=(String)session.getAttribute(uik);
		}
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println(" <html>"
				+ "<head><title>"+title+"</title></head>"
				+"\n"
				+"<body bgcolor='yellow' align='center'>\n\n\n\n"
				+"<h1>"+title+"</h1>\n"
				+"<h2>Session Information</h2>\n"
				+"<table border='1' align='center'>"
				+"<tr><th>Session Info</th><th>Value</th></tr>\n"
				+"<tr><td>id</td><td>"+session.getId()+"</td></tr>\n"
						+"<tr><td>create time</td><td>"+ct+"</td></tr>\n" 
								+"<tr><td>last time</td><td>"+lt+"</td></tr>\n"
										+"<tr><td>user ID</td><td>"+ui+"</td></tr>\n"
												+"<tr><td>Visit</td><td>"+vc+"</td></tr></table>\n"
				
				+ "</body></html>");
		
		
		
		
		
		
		
		
		
				
				
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
