import java.sql.Connection


public class Dao {
private String url1="jdbc:mysql://localhost:3306/sonoo";
private String dbname="root";
private String pass="";
private String db12="com.mysql.jdbc.Driver";
}
