package profile;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class profile
 */
@WebServlet("/profile")
public class profile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public profile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter out = response.getWriter();
		 out.print("<html><head><title>Profile</title></head>");
		 out.print("<body bgcolor='blue'>");
		 out.print("<div class='main'>");
		 out.print("<div class='header'>");
		 out.print("<h1 align='center'>Profile Page</h1></div><hr>");
		 out.print("<div class='body' align='center'>");
		 out.print("<div class='left' style='height: 500px; width: 40%; float: left;'>");
		 out.print("<img src='p.jpg' style='max-width: 200px; border-radius: 50%;'>");
		 out.print("<h3>Personal Details</h3>");
		 out.print("<h5>Name: Praveen Sanpada</h5>");
		 out.print("<h5>Mobile: 9876543211</h5>");
		 out.print("<h5>Email: praveen@gmail.com</h5>");
		 out.print("<h5>Degree: B.Tech</h5></div>");
		 out.print("<div class='right' style='height: 500px; width: 60%; float: right; '>");
		 out.print("<h1>Skills</h1>");
		 out.print("<h3>C Programming</h3>");
		 out.print("<h3>CPP Programming</h3>");
		 out.print("<h3>JAVA Programming</h3>");
		 out.print("<h3>PYTHON Programming</h3>");
		 out.print("<h3>Web Development</h3>");
		 out.print("<h3>Android Development</h3>");
		 out.print("<h3>Data Scientist</h3></div></div><hr>");
		 out.print("<div class='footer' style='padding-bottom: 10px;'>");
		 out.print("<p align='center'>Copyright@praveen.com</p></div></div>");
		 out.print("</body>");
		 out.print("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
