package ppp;

import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Add extends HttpServlet{
	
	public void service(HttpServletRequest req,HttpServletResponse res){
		String n=req.getParameter("name");
		System.out.print(n);
		//PrintWriter out =
	}

}
