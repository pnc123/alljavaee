package chat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class chat
 */
@WebServlet("/chat")
public class chat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public chat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
    String query= req.getParameter("query"); 
    String context=req.getParameter("context"); 
    String score = req.getParameter("lastScore");
    Socket client=null;
    Socket controlClient=null;
    Socket dataClient=null;
    String ip="172.16.13.87"; // ip of the remote host to connect to
    PrintWriter out=null;     
    BufferedReader in=null;
    String inLine="";//message received from remote host
    String outLine="";  // message to be sent to remote host
      
    PrintWriter sout = res.getWriter(); // Writer to write to the response
    res.setContentType("text/html");
    try
    {
    int newControlPort=0; // new Control port to be received from remote host
    int newDataPort=0;    // new Data Port to be received from remote host
    inLine="nothing";
    outLine="";
    client = new Socket(ip,4444); // opening connection on the port to initiate communication. new ports will be received from this connection
    out= new PrintWriter(client.getOutputStream(),true); // to send ack 
    in= new BufferedReader(new InputStreamReader(client.getInputStream())); // to receive new port numbers
    System.out.println("initialized in and  out on" + client.getPort() + client.getLocalSocketAddress());
    while(!in.ready())
    {
    //System.out.println("waiting for server ready");
    //yield();
    }
    newControlPort=Integer.parseInt(in.readLine().trim()); // received new control port
    if(newControlPort!=0)
    {
    System.out.println("new control port is " + newControlPort);
    out.close();
    in.close();
    client.close();
    try
    {
    //opening connection on the new control port
    controlClient = new Socket(ip,newControlPort); 
    System.out.println("new control port is " + controlClient.getPort()); 
     
    }
    catch(IOException ie)
    {
    ie.printStackTrace();
    }
    // initializing reader and writer for new control port
    PrintWriter controlOut= new PrintWriter(controlClient.getOutputStream(),true);
    BufferedReader controlIn= new BufferedReader(new InputStreamReader(controlClient.getInputStream()));
    while(!(controlIn.ready()))
    {
    //System.out.println("waiting for server");
    //yield();
    }
    inLine = controlIn.readLine().trim();
    if(inLine.equals("ok"))
    {
    controlOut.println("connected"); // ack to remote host that connection was successful
    controlOut.flush(); 
    }
     
    while(!controlIn.ready())
    {
    //yield();
    //System.out.println("connected on new port and waiting");
    }
    //received new Data port to receive data(Objects) from remote host
    newDataPort = Integer.parseInt(controlIn.readLine().trim());
    dataClient = new Socket(ip,newDataPort);
    System.out.println("port is" + dataClient.getPort() + dataClient.getLocalPort());
    // creating object streams to receive data
    ObjectOutputStream oos = new ObjectOutputStream(dataClient.getOutputStream());
    ObjectInputStream ois = new ObjectInputStream(dataClient.getInputStream());
    controlOut.println("data");
    controlOut.flush();
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
