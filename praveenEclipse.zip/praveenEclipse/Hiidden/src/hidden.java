

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/hidden")
public class hidden extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter ppp=response.getWriter();
		
		ppp.print("<h1>helllo</h1>");
		
		/*String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		
		ppp.println("<center><form action='second' method='post'>");
		ppp.println("Enter Email:-<input type='email' name='email'>");
		ppp.println("Enter Mobile:-<input type='text' name='mobile'>");
		ppp.println("<input type='hidden' name='name' value="+uname+">");
		ppp.println("<input type='hidden' name='pass' value="+pass+">");
		ppp.println("<input type='submit' value='Submit'>");
		ppp.println("</form></center>");
		*/
	}

}
