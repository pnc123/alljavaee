

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class second
 */
@WebServlet("/second")
public class second extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
     
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		response.setContentType("text/html");
		PrintWriter ppp=response.getWriter();
		
		String uname=request.getParameter("name");
		String pass=request.getParameter("pass");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		
		ppp.println("<center>");
		ppp.println("<h1>"+uname+"</h1>");
		ppp.println("<h1>"+pass+"</h1>");
		ppp.println("<h1>"+email+"</h1>");
		ppp.println("<h1>"+mobile+"</h1>");;
		ppp.println("</center>");
	}

}
